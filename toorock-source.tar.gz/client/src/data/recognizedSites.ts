export type RecognizedSite = {
  id: string;
  name: string;
  category: string;
  onionUrl: string;
  sourceUrl: string;
  official: boolean;
};

const torSource = "https://onion.torproject.org/";
const tor = (id: string, name: string, category: string, onionUrl: string): RecognizedSite => ({ id, name, category, onionUrl, sourceUrl: torSource, official: true });

export const recognizedSites: RecognizedSite[] = [
  { id: "amnesty", name: "Amnesty International", category: "Human rights", onionUrl: "https://www.amnestyl337aduwuvpf57irfl54ggtnuera45ygcxzuftwxjvvmpuzqd.onion/", sourceUrl: "https://www.amnesty.org/en/latest/news/2023/12/global-amnesty-international-website-launches-on-tor-network-to-help-universal-access/", official: true },
  { id: "ap-securedrop", name: "Associated Press SecureDrop", category: "Newsroom / SecureDrop", onionUrl: "https://kutj6adn66vdrpauox236wbc6g52ogg3pl4nfb5bfx7gzdgnqvhsl2qd.onion/", sourceUrl: "https://www.ap.org/contact-us/news-tips/", official: true },
  { id: "guardian", name: "The Guardian", category: "Newsroom", onionUrl: "https://guardian2zotagl6tmjucg3lrhxdk4dw3lhbqnkvvkywawy3oqfoprid.onion/", sourceUrl: "https://www.theguardian.com/help/insideguardian/2022/may/30/guardian-launches-tor-onion-service", official: true },
  { id: "bbc", name: "BBC News", category: "Newsroom", onionUrl: "https://bbcweb3hytmzhn5d532owbu6oqadra5z3ar726vq5kgwwn6aucdccrad.onion/", sourceUrl: "https://www.bbc.com/news/technology-50150981", official: true },
  { id: "propublica", name: "ProPublica", category: "Investigative newsroom", onionUrl: "http://p53lf57qovyuvwsc6xnrppyply3vtqm7l6pcobkmyqsiofyeznfu5uqd.onion/", sourceUrl: "https://www.propublica.org/nerds/a-more-secure-and-anonymous-propublica-using-tor-hidden-services", official: true },
  tor("tor-archive", "Tor Project Archive", "Software archive", "http://uy3qxvwzwoeztnellvvhxh7ju7kfvlsauka7avilcjg7domzxptbq7qd.onion/"),
  tor("arti", "Arti", "Software documentation", "http://hjirlp6fu47kox4cnede4zlvaeq672bibss3oxgmsnsc5mdxygqshbqd.onion/"),
  tor("aus1", "Tor Project AUS1", "Update service", "http://ot3ivcdxmalbsbponeeq5222hftpf3pqil24q3s5ejwo5t52l65qusid.onion/"),
  tor("aus2", "Tor Project AUS2", "Update service", "http://b5t7emfr2rn3ixr4lvizpi3stnni4j4p6goxho7lldf4qg4hz5hvpqid.onion/"),
  tor("tor-blog", "Tor Blog", "Publication", "http://pzhdfe7jraknpj2qgu5cz2u3i4deuyfwmonvzu5i3nyw4t4bmg7o5pad.onion/"),
  tor("bridges", "Tor Bridges", "Censorship circumvention", "http://yq5jjvr7drkjrelzhut7kgclfuro65jjlivyzfmxiq2kyv5lickrl4qd.onion/"),
  tor("cloud", "Tor Cloud", "Collaboration", "http://ui3cpcohcoko6aydhuhlkwqqtvadhaflcc5zb7mwandqmcal7sbwzwqd.onion/"),
  tor("collector", "Tor CollecTor", "Network data", "http://pgmrispjerzzf2tdzbfp624cg5vpbvdw2q5a3hvtsbsx25vnni767yad.onion/"),
  tor("collector2", "Tor CollecTor 2", "Network data", "http://urscdffm73o4y6hpp3r43bgmudq42hq2ibdpkld6a7hy3qa44qbvc2yd.onion/"),
  tor("community", "Tor Community", "Community", "http://xmrhfasfg5suueegrnc4gsgyi2tyclcy5oz7f5drnrodmdtob6t2ioyd.onion/"),
  tor("consensus", "Tor Consensus Health", "Network monitoring", "http://tkskz5dkjel4xqyw5d5l3k52kgglotwn6vgb5wrl2oa5yi2szvywiyid.onion/"),
  tor("db", "Tor DB", "Developer service", "http://epnxy4oscv3yh2fjwfrvctnjsmj5ta5uxdkq6k2ce7borqvcsk4qxhid.onion/"),
  tor("tails-deb", "Tails Debian Repository", "Package repository", "http://umjqavufhoix3smyq6az2sx4istmuvsgmz4bq5u5x56rnayejoo6l2qd.onion/"),
  tor("tor-deb", "Tor Debian Repository", "Package repository", "http://apow7mjfryruh65chtdydfmqfpj5btws7nbocgtaovhvezgccyjazpqd.onion/"),
  tor("dist", "Tor Distribution", "Software distribution", "http://scpalcwstkydpa3y7dbpkjs2dtr7zvtvdbyj3dqwkucfrwyixcl5ptqd.onion/"),
  tor("download", "Tor Download", "Software downloads", "http://vczcbkhpkhcywcyuyd7rfhu4bebsyscp2qoeyyvjva3km5py5rpisdid.onion/"),
  tor("exonerator", "Tor ExoneraTor", "Verification tool", "http://pm46i5h2lfewyx6l7pnicbxhts2sxzacvsbmqiemqaspredf2gm3dpad.onion/"),
  tor("extra", "Tor Extra", "Project resources", "http://kkr72iohlfix5ipjg776eyhplnl2oiv5tz4h2y2bkhjix3quafvjd5ad.onion/"),
  tor("forum", "Tor Forum", "Community forum", "http://v236xhqtyullodhf26szyjepvkbv6iitrhjgrqj4avaoukebkk6n6syd.onion/"),
  tor("gitlab", "Tor GitLab", "Code hosting", "http://eweiibe6tdjsdprb4px6rqrzzcsi22m4koia44kc5pcjr7nec2rlxyad.onion/"),
  tor("irc", "Tor IRC Bouncer", "Communications", "http://moz5kotsnjony4oxccxfo4lwk3pvoxmdoljibhgoonzgzjs5oemtjmqd.onion/"),
  tor("lists", "Tor Mailing Lists", "Communications", "http://e6r6heg2ucmlm2po5yrxzf6k23ta5wwbt2adogjcyntlaiopytjz35yd.onion/"),
  tor("metrics", "Tor Metrics", "Network statistics", "http://hctxrvjzfpvmzh2jllqhgvvkoepxb4kfzdjm6h7egcwlumggtktiftid.onion/"),
  tor("newsletter", "Tor Newsletter", "Publication", "http://a4ygisnerpgtc5ayerl22pll6cls3oyj54qgpm7qrmb66xrxts6y3lyd.onion/"),
  tor("nightlies", "Tor Browser Nightlies", "Build distribution", "http://umj4zbqdfcyevlkgqgpq6foxk3z75zzxsbgt5jqmfxofrbrjh3crbnad.onion/"),
  tor("nyx", "Nyx", "Network monitor", "http://3ewfgrt4gzfccp6bnquhqb266r3zepiqpnsk3falwygkegtluwuyevid.onion/"),
  tor("directory", "Tor Onion Directory", "Infrastructure", "http://xao2lxsmia2edq2n5zxg6uahx6xox2t7bfjw6b5vdzsxi7ezmqob6qid.onion/"),
  tor("onion-services", "Tor Onion Services", "Documentation", "http://ttevhjjsjxz6uqqcjkbig5cycd7n7xv7cmd6f5fcvrqaaa7f3bj36wad.onion/"),
  tor("openpgp", "Tor OpenPGP Key Service", "Cryptography", "http://2yldcptk56shc7lwieozoglw3t5ghty7m6mf2faysvfnzccqavbu2mad.onion/"),
  tor("people", "Tor People", "Project site", "http://5ecey6oe4rocdsfoigr4idu42cecm2j7zfogc3xc7kfn4uriehwrs6qd.onion/"),
  tor("research", "Tor Research", "Research", "http://xhqthou6scpfnwjyzc3ekdgcbvj76ccgyjyxp6cgypxjlcuhnxiktnqd.onion/"),
  tor("review", "Tor Review", "Code review", "http://zhkhhhnppc5k6xju7n25rjba3wuip73jnodicxl65qdpchrwvvsilcyd.onion/"),
  tor("rpm", "Tor RPM Repository", "Package repository", "http://4ayyzfoh5qdrokqaejis3rdredhvf22n3migyxfudpkpunngfc7g4lqd.onion/"),
  tor("snowflake", "Tor Snowflake", "Censorship circumvention", "http://oljlphash3bpqtrvqpr5gwzrhroziw4mddidi5d2qa4qjejcbrmoypqd.onion/"),
  tor("spec", "Tor Specifications", "Technical documentation", "http://i3xi5qxvbrngh3g6o7czwjfxwjzigook7zxzjmgwg5b7xnjcn5hzciad.onion/"),
  tor("stem", "Stem", "Developer library", "http://mf34jlghauz5pxjcmdymdqbe5pva4v24logeys446tdrgd5lpsrocmqd.onion/"),
  tor("styleguide", "Tor Style Guide", "Documentation", "http://7khzpw47s35pwo3lvtctwf2szvnq3kgglvzc22elx7of2awdzpovqmqd.onion/"),
  tor("submission", "Tor Submission", "Contact service", "http://givpjczyrb5jjseful3o5tn3tg7tidbu4gydl4sa5ekpcipivqaqnpad.onion/"),
  tor("support", "Tor Support", "Support", "http://rzuwtpc4wb3xdzrj3yeajsvm3fkq4vbeubm2tdxaqruzzzgs5dwemlad.onion/"),
  tor("survey", "Tor Survey", "Research survey", "http://eh5esdnd6fkbkapfc6nuyvkjgbtnzq2is72lmpwbdbxepd2z7zbgzsqd.onion/"),
  tor("svn", "Tor SVN Archive", "Historical archive", "http://b63iq6es4biaawfilwftlfkw6a6putogxh4iakei2ioppb7dsfucekyd.onion/"),
  tor("tails", "Tails", "Privacy software", "http://tzoz3bensgxyzs7da7lpgsn3a74h7hlbm4wa6ytq2tg6ktd57w22vqqd.onion/"),
  tor("manual", "Tor Browser Manual", "Documentation", "http://dsbqrprgkqqifztta6h3w7i2htjhnq7d3qkh3c7gvc35e66rrcv66did.onion/"),
  tor("onion-router", "Onion Router", "Privacy education", "http://tttyx2vwp7ihml3vkhywwcizv6nbwrikpgeciy3qrow7l7muak2pnhad.onion/"),
  tor("tor-main", "Tor Project", "Privacy software", "http://2gzyxa5ihm7nsggfxnu52rck2vv4rvmdlkiu3zzui5du4xyclen53wid.onion/"),
  tor("duckduckgo", "DuckDuckGo", "Search", "http://duckduckgogg42xjoc72x3sjasowoarfbgcmvfimaftt6twagswzczad.onion/"),
];
