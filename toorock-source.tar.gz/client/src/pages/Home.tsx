import { FormEvent, useMemo, useState } from "react";
import {
  ArrowRight,
  Check,
  Copy,
  ExternalLink,
  Globe2,
  LoaderCircle,
  Menu,
  Network,
  Radio,
  Terminal,
  X,
} from "lucide-react";
import { toast } from "sonner";

const GATEWAY_ORIGIN = (import.meta.env.VITE_GATEWAY_URL || "https://toorock.onrender.com").replace(/\/$/, "");
const ONION_V3 = /^[a-z2-7]{56}\.onion$/i;
const sampleTargets = [
  { label: "DuckDuckGo", value: "http://duckduckgogg42xjoc72x3sjasowoarfbgcmvfimaftt6twagswzczad.onion/" },
];

function normalizeTarget(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return "";
  return /^[a-z][a-z\d+.-]*:\/\//i.test(trimmed) ? trimmed : `http://${trimmed}`;
}

function toGatewayUrl(target: string) {
  return `${GATEWAY_ORIGIN}/gateway/proxy?url=${encodeURIComponent(target)}`;
}

export default function Home() {
  const [target, setTarget] = useState("");
  const [activeTarget, setActiveTarget] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  const gatewayTarget = useMemo(() => activeTarget ? toGatewayUrl(activeTarget) : "", [activeTarget]);
  const statusLabel = loading ? "TOR CONNECTING" : activeTarget ? "SESSION LIVE" : "GATEWAY READY";

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    const normalized = normalizeTarget(target);
    if (!normalized) {
      toast.error("Enter a destination address first.");
      return;
    }
    try {
      const parsed = new URL(normalized);
      if (!["http:", "https:"].includes(parsed.protocol) || !ONION_V3.test(parsed.hostname)) throw new Error();
    } catch {
      toast.error("Use a valid v3 .onion address.");
      return;
    }
    setLoaded(false);
    setFailed(false);
    setLoading(true);
    setActiveTarget(normalized);
    toast.success("Tor route opened. Establishing isolated view.");
  }

  function clearSession() {
    setLoading(false);
    setLoaded(false);
    setFailed(false);
    setActiveTarget("");
  }

  async function copyTarget() {
    if (!activeTarget) return;
    await navigator.clipboard?.writeText(activeTarget);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="app-shell">
      <div className="noise" aria-hidden="true" />
      <header className="site-header">
        <a className="brand" href="#top" aria-label="TooRocK home">
          <span className="brand-mark"><span /></span>
          <span className="brand-name">TooRocK</span>
        </a>
        <nav className={mobileOpen ? "nav-links open" : "nav-links"} aria-label="Primary navigation">
          <a href="#workspace" onClick={() => setMobileOpen(false)}>Gateway</a>
          <a href="#session" onClick={() => setMobileOpen(false)}>Session</a>
        </nav>
        <div className="header-actions">
          <span className="status-pill"><span className="status-dot" /> {statusLabel}</span>
          <button className="menu-button" onClick={() => setMobileOpen((value) => !value)} aria-label="Toggle navigation">
            {mobileOpen ? <X size={19} /> : <Menu size={19} />}
          </button>
        </div>
      </header>

      <main id="top">
        <section className="hero-section">
          <div className="hero-copy">
            <p className="eyebrow"><Radio size={14} /> PRIVATE ROUTING LAYER / 01</p>
            <h1>Browse Beyond<br /><span>The Visible Web :-/</span></h1>
            <p className="hero-description">Access Deep &amp; Dark Web With Security &amp; Safety :-)</p>
          </div>
          <div className="hero-orbit" aria-hidden="true">
            <div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="orbit orbit-three" />
            <div className="orbit-core"><Terminal size={33} strokeWidth={1.2} /><span>TOR<br />READY</span></div>
          </div>
        </section>

        <section className="workspace" id="workspace" aria-label="Tor gateway workspace">
          <div className="workspace-heading">
            <div><span className="section-index">02</span><h2>Open an onion session</h2></div>
            <span className="latency"><span className="pulse-dot" /> gateway online</span>
          </div>
          <form className="target-form" onSubmit={handleSubmit}>
            <div className="input-wrap"><Globe2 size={18} /><input aria-label="Onion destination" value={target} onChange={(event) => setTarget(event.target.value)} placeholder="Enter a v3 .onion address" spellCheck={false} /><span className="input-suffix">HTTPS / HTTP</span></div>
            <button className="primary-button" type="submit">Connect <ArrowRight size={17} /></button>
          </form>
          <div className="quick-row"><span className="quick-label">Public route</span>{sampleTargets.map((item) => <button key={item.label} type="button" className="quick-link" onClick={() => setTarget(item.value)}>{item.label}<ExternalLink size={12} /></button>)}</div>

          <div className={activeTarget ? "session-panel active" : "session-panel"} id="session">
            <div className="session-topline"><div><span className="live-indicator"><span /> {loading ? "TOR HANDSHAKE" : loaded ? "LIVE SESSION" : "READY"}</span><span className="session-address">{activeTarget || "No destination connected"}</span></div><div className="session-controls"><button type="button" aria-label="Copy destination" onClick={copyTarget}>{copied ? <Check size={16} /> : <Copy size={16} />}</button><button type="button" aria-label="Open gateway view in new tab" onClick={() => gatewayTarget && window.open(gatewayTarget, "_blank", "noopener,noreferrer")}><ExternalLink size={16} /></button><button type="button" aria-label="Clear session" onClick={clearSession}><X size={16} /></button></div></div>
            {!activeTarget && <div className="session-empty"><div className="empty-icon"><Network size={22} /></div><h3>Waiting for a destination</h3><p>Paste an onion address to open it here.</p></div>}
            {activeTarget && loading && <div className="loading-state"><div className="loading-ring"><LoaderCircle size={46} /></div><p className="loading-title">ESTABLISHING TOR CIRCUIT</p><p className="loading-copy">The gateway is resolving the onion service. This can take a moment.</p><div className="loading-bars"><span /><span /><span /><span /><span /></div></div>}
            {activeTarget && failed && <div className="session-empty"><div className="empty-icon"><X size={22} /></div><h3>Gateway view could not load</h3><p>Check the onion address and try again. The route accepts HTTP and HTTPS v3 onion services only.</p></div>}
            {activeTarget && <iframe className={loaded ? "onion-frame loaded" : "onion-frame"} title="Onion service isolated view" src={gatewayTarget} onLoad={() => { setLoading(false); setLoaded(true); setFailed(false); }} onError={() => { setLoading(false); setFailed(true); }} />}
            <div className="session-footer"><span>TooRocK</span></div>
          </div>
        </section>
      </main>

      <footer className="site-footer"><span>TooRocK - Humayun Shariar Himu</span></footer>
    </div>
  );
}
