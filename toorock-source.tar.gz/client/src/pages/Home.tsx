import { FormEvent, useMemo, useState } from "react";
import {
  ArrowRight,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  Copy,
  ExternalLink,
  Globe2,
  History,
  LockKeyhole,
  Menu,
  Network,
  Radio,
  ShieldCheck,
  Terminal,
  X,
} from "lucide-react";
import { toast } from "sonner";

const sampleTargets = [
  { label: "Tor Project", value: "https://www.torproject.org" },
  { label: "SecureDrop", value: "http://exampleonionaddress.onion" },
  { label: "Onion Service", value: "http://your-service.onion" },
];

function normalizeTarget(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return "";
  return /^https?:\/\//i.test(trimmed) ? trimmed : `http://${trimmed}`;
}

export default function Home() {
  const [target, setTarget] = useState("");
  const [activeTarget, setActiveTarget] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const statusLabel = useMemo(() => (activeTarget ? "SESSION READY" : "GATEWAY READY"), [activeTarget]);

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    const normalized = normalizeTarget(target);
    if (!normalized) {
      toast.error("Enter a destination address first.");
      return;
    }
    try {
      const parsed = new URL(normalized);
      if (!["http:", "https:"].includes(parsed.protocol)) throw new Error();
      if (!parsed.hostname.includes(".onion") && parsed.hostname !== "localhost") {
        toast.error("Use a valid .onion hostname for Tor routing.");
        return;
      }
    } catch {
      toast.error("That destination is not a valid URL.");
      return;
    }
    setActiveTarget(normalized);
    toast.success("Secure session prepared.");
  }

  async function copyTarget() {
    if (!activeTarget) return;
    await navigator.clipboard?.writeText(activeTarget);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="app-shell">
      <div className="noise" aria-hidden="true" />
      <header className="site-header">
        <a className="brand" href="#top" aria-label="TooRocK home">
          <span className="brand-mark"><span /></span>
          <span className="brand-name">TooRocK</span>
        </a>
        <nav className={mobileOpen ? "nav-links open" : "nav-links"} aria-label="Primary navigation">
          <a href="#how-it-works" onClick={() => setMobileOpen(false)}>How it works</a>
          <a href="#security" onClick={() => setMobileOpen(false)}>Security</a>
          <a href="#about" onClick={() => setMobileOpen(false)}>About</a>
        </nav>
        <div className="header-actions">
          <span className="status-pill"><span className="status-dot" /> {statusLabel}</span>
          <button className="menu-button" onClick={() => setMobileOpen((value) => !value)} aria-label="Toggle navigation">
            {mobileOpen ? <X size={19} /> : <Menu size={19} />}
          </button>
        </div>
      </header>

      <main id="top">
        <section className="hero-section">
          <div className="hero-copy">
            <p className="eyebrow"><Radio size={14} /> PRIVATE ROUTING LAYER / 01</p>
            <h1>Browse beyond<br /><span>the visible web.</span></h1>
            <p className="hero-description">TooRocK is a clean, security-first gateway interface for reaching valid onion services through a Tor-powered Render gateway.</p>
            <div className="hero-meta">
              <span><ShieldCheck size={15} /> No third-party rewrites</span>
              <span><Network size={15} /> SOCKS5 routed</span>
            </div>
          </div>
          <div className="hero-orbit" aria-hidden="true">
            <div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="orbit orbit-three" />
            <div className="orbit-core"><Terminal size={33} strokeWidth={1.2} /><span>TOR<br />READY</span></div>
          </div>
        </section>

        <section className="workspace" aria-label="Tor gateway workspace">
          <div className="workspace-heading">
            <div><span className="section-index">02</span><h2>Open a secure session</h2></div>
            <span className="latency"><span className="pulse-dot" /> gateway latency nominal</span>
          </div>
          <form className="target-form" onSubmit={handleSubmit}>
            <div className="input-wrap"><Globe2 size={18} /><input aria-label="Onion destination" value={target} onChange={(event) => setTarget(event.target.value)} placeholder="Enter a .onion address" spellCheck={false} /><span className="input-suffix">HTTPS / HTTP</span></div>
            <button className="primary-button" type="submit">Connect <ArrowRight size={17} /></button>
          </form>
          <div className="quick-row"><span className="quick-label">Try a route</span>{sampleTargets.map((item) => <button key={item.label} type="button" className="quick-link" onClick={() => setTarget(item.value)}>{item.label}<ExternalLink size={12} /></button>)}</div>

          <div className={activeTarget ? "session-panel active" : "session-panel"}>
            <div className="session-topline"><div><span className="live-indicator"><span /> LIVE SESSION</span><span className="session-address">{activeTarget || "No destination connected"}</span></div><div className="session-controls"><button type="button" aria-label="Copy destination" onClick={copyTarget}>{copied ? <Check size={16} /> : <Copy size={16} />}</button><button type="button" aria-label="Clear session" onClick={() => setActiveTarget("")}><X size={16} /></button></div></div>
            <div className="session-empty"><div className="empty-icon"><LockKeyhole size={22} /></div><h3>{activeTarget ? "Session is ready" : "Your secure view appears here"}</h3><p>{activeTarget ? "The Render gateway is ready to route this destination through Tor." : "Enter a valid onion address above. Content stays inside the isolated gateway view."}</p></div>
            <div className="session-footer"><span><Clock3 size={14} /> 30s request timeout</span><span><ShieldCheck size={14} /> SSRF checks enabled</span><span><Network size={14} /> Render / Tor SOCKS5</span></div>
          </div>
        </section>

        <section className="feature-grid" id="how-it-works">
          <article className="feature-card"><span className="feature-number">01</span><LockKeyhole size={21} /><h3>Private by design</h3><p>Requests are isolated at the gateway layer. No open internet proxy and no direct browser-to-onion connection.</p></article>
          <article className="feature-card" id="security"><span className="feature-number">02</span><ShieldCheck size={21} /><h3>Security first</h3><p>Protocol checks, hostname validation, request limits and timeout controls are built into the route.</p></article>
          <article className="feature-card" id="about"><span className="feature-number">03</span><History size={21} /><h3>Clear boundaries</h3><p>TooRocK targets HTTP and HTTPS onion services. Compatibility depends on each service's own browser requirements.</p></article>
        </section>

        <section className="faq-strip"><CircleHelp size={18} /><div><strong>New to onion services?</strong><span>Only connect to destinations you trust. Never share sensitive credentials with an unknown service.</span></div><ChevronDown size={18} /></section>
      </main>

      <footer className="site-footer"><span>TOOROCK / SECURE ROUTING INTERFACE</span><span>BUILT FOR THE OPEN WEB</span></footer>
    </div>
  );
}
