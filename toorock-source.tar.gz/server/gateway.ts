import type { Express, Request, Response } from "express";
import http from "node:http";
import https from "node:https";
import net from "node:net";
import { URL } from "node:url";
import { SocksProxyAgent } from "socks-proxy-agent";
import { load } from "cheerio";

const MAX_RESPONSE_BYTES = 10 * 1024 * 1024;
const REQUEST_TIMEOUT_MS = 90_000;
const onionV3 = /^[a-z2-7]{56}\.onion$/i;
const allowedClearWebHosts = new Set(["duckduckgo.com", "www.duckduckgo.com"]);

export function parseOnionUrl(raw: unknown) {
  if (typeof raw !== "string" || raw.length > 2048) throw new Error("Invalid target");
  const value = /^[a-z][a-z\d+.-]*:\/\//i.test(raw) ? raw : `http://${raw}`;
  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    throw new Error("Invalid target URL");
  }
  if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error("Only HTTP and HTTPS are supported");
  if (!onionV3.test(parsed.hostname)) throw new Error("Only valid v3 onion services are supported");
  if (parsed.port && !['80', '443'].includes(parsed.port)) throw new Error("Unsupported target port");
  return parsed;
}

export function parseGatewayTarget(raw: unknown) {
  if (typeof raw !== "string" || raw.length > 2048) throw new Error("Invalid target");
  const value = /^[a-z][a-z\d+.-]*:\/\//i.test(raw) ? raw : `http://${raw}`;
  let parsed: URL;
  try { parsed = new URL(value); } catch { throw new Error("Invalid target URL"); }
  if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("Only HTTP and HTTPS are supported");
  if (!onionV3.test(parsed.hostname) && !allowedClearWebHosts.has(parsed.hostname.toLowerCase())) throw new Error("Target host is not allowed");
  if (parsed.port && !['80', '443'].includes(parsed.port)) throw new Error("Unsupported target port");
  return parsed;
}

function unwrapGatewayTarget(raw: unknown) {
  if (Array.isArray(raw)) raw = raw[0];
  if (typeof raw !== "string") return raw;
  let candidate = raw.trim();
  // Browsers sometimes submit the already-open gateway URL back to the
  // proxy. Unwrap it so searches and ordinary links do not become targets.
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const parsed = new URL(candidate);
      const nested = parsed.searchParams.get("url");
      if (!nested) break;
      candidate = nested;
    } catch {
      break;
    }
  }
  return candidate;
}

function gatewayUrl(target: URL, req: Request) {
  const base = `${req.protocol}://${req.get('host')}`;
  return `${base}/gateway/proxy?url=${encodeURIComponent(target.toString())}`;
}

function shouldProxyHost(hostname: string) {
  return onionV3.test(hostname) || allowedClearWebHosts.has(hostname.toLowerCase());
}

function rewriteMarkup(body: string, target: URL, req: Request) {
  const $ = load(body);
  const rewrite = (value: string | undefined) => {
    if (!value || value.startsWith('#') || /^(data:|javascript:|mailto:|tel:)/i.test(value)) return value;
    try {
      const resolved = new URL(value, target);
      return shouldProxyHost(resolved.hostname) ? gatewayUrl(resolved, req) : value;
    } catch {
      return value;
    }
  };
  $('a[href], link[href], img[src], script[src], source[src], iframe[src], video[src], audio[src], form[action], form').each((_, el) => {
    const node = $(el);
    if (node.attr('href')) node.attr('href', rewrite(node.attr('href')));
    if (node.attr('src')) node.attr('src', rewrite(node.attr('src')));
    if (node.is('form')) node.attr('action', rewrite(node.attr('action') || target.toString()));
    if (node.attr('action')) node.attr('action', rewrite(node.attr('action')));
  });
  const gateway = `${req.protocol}://${req.get('host')}`;
  const targetLiteral = JSON.stringify(target.toString());
  const gatewayLiteral = JSON.stringify(gateway);
  $('head').prepend(`<base href="${target.toString().replaceAll('"', '&quot;')}"><style id="toorock-progress-style">#toorock-nav-progress{display:none;position:fixed;z-index:2147483647;top:0;left:0;width:42%;height:3px;background:#fff;box-shadow:0 0 14px #fff;animation:toorock-progress 1.2s ease-in-out infinite}@keyframes toorock-progress{0%{transform:translateX(-110%)}100%{transform:translateX(260%)}}</style><script>(function(){const t=${targetLiteral},g=${gatewayLiteral};const p=document.createElement('div');p.id='toorock-nav-progress';document.documentElement.appendChild(p);const show=()=>p.style.display='block',hide=()=>p.style.display='none';function r(v){try{const u=new URL(String(v),t);const h=u.hostname.toLowerCase();return (h.endsWith('.onion')||h==='duckduckgo.com'||h==='www.duckduckgo.com')?g+'/gateway/proxy?url='+encodeURIComponent(u.toString()):String(v)}catch{return v}}document.addEventListener('click',function(e){const a=e.target.closest&&e.target.closest('a[href]');if(a)show()},true);document.addEventListener('submit',function(e){const a=e.target.getAttribute('action');show();if(a&&a.indexOf('/gateway/proxy')<0)e.target.setAttribute('action',r(a))},true);const f=window.fetch;window.fetch=function(i,o){show();const u=typeof i==='string'?r(i):r(i.url);return f.call(this,typeof i==='string'?u:new Request(u,i),o).finally(hide)};const xo=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(m,u){show();this.addEventListener('loadend',hide,{once:true});return xo.call(this,m,r(u),...Array.prototype.slice.call(arguments,2))};window.addEventListener('load',hide)})()</script>`);
  return $.html();
}

function requestThroughTor(target: URL, req: Request, res: Response) {
  const host = process.env.TOR_SOCKS_HOST || '127.0.0.1';
  const port = Number(process.env.TOR_SOCKS_PORT || 9050);
  const agent = new SocksProxyAgent(`socks5h://${host}:${port}`);
  const transport = target.protocol === 'https:' ? https : http;
  const upstream = transport.request(target, {
    method: req.method,
    headers: {
      'user-agent': 'TooRocK/1.0 (+secure gateway)',
      accept: req.get('accept') || '*/*',
      ...(req.get('content-type') ? { 'content-type': req.get('content-type') } : {}),
      ...(req.get('cookie') ? { cookie: req.get('cookie') } : {}),
    },
    agent,
    timeout: REQUEST_TIMEOUT_MS,
  }, (upstreamRes) => {
    const contentType = String(upstreamRes.headers['content-type'] || 'application/octet-stream');
    const chunks: Buffer[] = [];
    let size = 0;
    upstreamRes.on('data', (chunk: Buffer) => {
      size += chunk.length;
      if (size <= MAX_RESPONSE_BYTES) chunks.push(chunk);
      else upstreamRes.destroy(new Error('Response too large'));
    });
    upstreamRes.on('end', () => {
      if (res.headersSent) return;
      if (size > MAX_RESPONSE_BYTES) return res.status(413).send('Response exceeds gateway limit.');
      const buffer = Buffer.concat(chunks);
      res.status(upstreamRes.statusCode || 502);
      if (upstreamRes.headers['set-cookie']) {
        const cookies = Array.isArray(upstreamRes.headers['set-cookie']) ? upstreamRes.headers['set-cookie'] : [upstreamRes.headers['set-cookie']];
        res.setHeader('set-cookie', cookies.map((cookie) => cookie.replace(/;\s*Domain=[^;]+/gi, '').replace(/;\s*SameSite=[^;]+/gi, '')));
      }
      if (upstreamRes.headers.location) {
        try {
          const redirected = new URL(upstreamRes.headers.location, target);
          if (onionV3.test(redirected.hostname)) {
            res.setHeader('location', gatewayUrl(redirected, req));
          }
        } catch {
          // Ignore malformed upstream locations instead of leaking a direct target.
        }
      }
      if (contentType.includes('text/html')) {
        res.type('html').send(rewriteMarkup(buffer.toString('utf8'), target, req));
      } else {
        res.setHeader('content-type', contentType);
        res.send(buffer);
      }
    });
  });
  upstream.on('timeout', () => upstream.destroy(new Error('Gateway timeout')));
  upstream.on('error', (error) => { if (!res.headersSent) res.status(502).send(`Gateway unavailable: ${error.message}`); });
  if (req.method !== 'GET' && req.method !== 'HEAD') req.pipe(upstream); else upstream.end();
}

function torReady() {
  const host = process.env.TOR_SOCKS_HOST || '127.0.0.1';
  const port = Number(process.env.TOR_SOCKS_PORT || 9050);
  return new Promise<boolean>((resolve) => {
    const socket = net.createConnection({ host, port });
    const finish = (ready: boolean) => {
      socket.destroy();
      resolve(ready);
    };
    socket.setTimeout(1000);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
  });
}

function torBootstrapReady() {
  return new Promise<boolean>((resolve) => {
    const socket = net.createConnection({ host: '127.0.0.1', port: 9051 });
    let output = '';
    let settled = false;
    const finish = (ready: boolean) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve(ready);
    };
    socket.setTimeout(1500);
    socket.once('connect', () => socket.write('AUTHENTICATE\r\nGETINFO status/bootstrap-phase\r\nQUIT\r\n'));
    socket.on('data', (chunk) => { output += chunk.toString(); if (output.includes('PROGRESS=100')) finish(true); });
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.once('close', () => finish(output.includes('PROGRESS=100')));
  });
}

async function waitForTorBootstrap(timeoutMs = 120_000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await torBootstrapReady()) return true;
    await new Promise((resolve) => setTimeout(resolve, 2000));
  }
  return false;
}

export function registerGatewayRoutes(app: Express) {
  app.get('/health', async (_req, res) => {
    const tor = await torReady();
    const bootstrapped = tor && await torBootstrapReady();
    res.status(bootstrapped ? 200 : 503).json({ status: bootstrapped ? 'ok' : 'degraded', service: 'toorock-render-gateway', tor: bootstrapped });
  });
  app.all('/gateway/proxy', async (req, res) => {
    try {
      const target = parseGatewayTarget(unwrapGatewayTarget(req.query.url));
      if (!(await waitForTorBootstrap())) return res.status(503).json({ error: 'Tor network is still bootstrapping. Retry shortly.' });
      requestThroughTor(target, req, res);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Invalid target' });
    }
  });
}
