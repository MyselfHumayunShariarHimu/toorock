import type { Express, Request, Response } from "express";
import http from "node:http";
import https from "node:https";
import net from "node:net";
import { URL } from "node:url";
import { SocksProxyAgent } from "socks-proxy-agent";
import { load } from "cheerio";

const MAX_RESPONSE_BYTES = 10 * 1024 * 1024;
const REQUEST_TIMEOUT_MS = 30_000;
const onionV3 = /^[a-z2-7]{56}\.onion$/i;

export function parseOnionUrl(raw: unknown) {
  if (typeof raw !== "string" || raw.length > 2048) throw new Error("Invalid target");
  const value = /^[a-z][a-z\d+.-]*:\/\//i.test(raw) ? raw : `http://${raw}`;
  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    throw new Error("Invalid target URL");
  }
  if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error("Only HTTP and HTTPS are supported");
  if (!onionV3.test(parsed.hostname)) throw new Error("Only valid v3 onion services are supported");
  if (parsed.port && !['80', '443'].includes(parsed.port)) throw new Error("Unsupported target port");
  return parsed;
}

function gatewayUrl(target: URL, req: Request) {
  const base = `${req.protocol}://${req.get('host')}`;
  return `${base}/gateway/proxy?url=${encodeURIComponent(target.toString())}`;
}

function rewriteMarkup(body: string, target: URL, req: Request) {
  const $ = load(body);
  const rewrite = (value: string | undefined) => {
    if (!value || value.startsWith('#') || /^(data:|javascript:|mailto:|tel:)/i.test(value)) return value;
    try {
      const resolved = new URL(value, target).toString();
      return gatewayUrl(new URL(resolved), req);
    } catch {
      return value;
    }
  };
  $('a[href], link[href], img[src], script[src], source[src], iframe[src], video[src], audio[src], form[action]').each((_, el) => {
    const node = $(el);
    if (node.attr('href')) node.attr('href', rewrite(node.attr('href')));
    if (node.attr('src')) node.attr('src', rewrite(node.attr('src')));
    if (node.attr('action')) node.attr('action', rewrite(node.attr('action')));
  });
  $('head').prepend(`<base href="${target.toString().replaceAll('"', '&quot;')}">`);
  return $.html();
}

function requestThroughTor(target: URL, req: Request, res: Response) {
  const host = process.env.TOR_SOCKS_HOST || '127.0.0.1';
  const port = Number(process.env.TOR_SOCKS_PORT || 9050);
  const agent = new SocksProxyAgent(`socks5h://${host}:${port}`);
  const transport = target.protocol === 'https:' ? https : http;
  const upstream = transport.request(target, {
    method: req.method,
    headers: {
      'user-agent': 'TooRocK/1.0 (+secure gateway)',
      accept: req.get('accept') || '*/*',
      ...(req.get('content-type') ? { 'content-type': req.get('content-type') } : {}),
      ...(req.get('cookie') ? { cookie: req.get('cookie') } : {}),
    },
    agent,
    timeout: REQUEST_TIMEOUT_MS,
  }, (upstreamRes) => {
    const contentType = String(upstreamRes.headers['content-type'] || 'application/octet-stream');
    const chunks: Buffer[] = [];
    let size = 0;
    upstreamRes.on('data', (chunk: Buffer) => {
      size += chunk.length;
      if (size <= MAX_RESPONSE_BYTES) chunks.push(chunk);
      else upstreamRes.destroy(new Error('Response too large'));
    });
    upstreamRes.on('end', () => {
      if (res.headersSent) return;
      if (size > MAX_RESPONSE_BYTES) return res.status(413).send('Response exceeds gateway limit.');
      const buffer = Buffer.concat(chunks);
      res.status(upstreamRes.statusCode || 502);
      if (upstreamRes.headers['set-cookie']) res.setHeader('set-cookie', upstreamRes.headers['set-cookie']);
      if (upstreamRes.headers.location) {
        try {
          const redirected = new URL(upstreamRes.headers.location, target);
          if (onionV3.test(redirected.hostname)) {
            res.setHeader('location', gatewayUrl(redirected, req));
          }
        } catch {
          // Ignore malformed upstream locations instead of leaking a direct target.
        }
      }
      if (contentType.includes('text/html')) {
        res.type('html').send(rewriteMarkup(buffer.toString('utf8'), target, req));
      } else {
        res.setHeader('content-type', contentType);
        res.send(buffer);
      }
    });
  });
  upstream.on('timeout', () => upstream.destroy(new Error('Gateway timeout')));
  upstream.on('error', (error) => { if (!res.headersSent) res.status(502).send(`Gateway unavailable: ${error.message}`); });
  if (req.method !== 'GET' && req.method !== 'HEAD') req.pipe(upstream); else upstream.end();
}

function torReady() {
  const host = process.env.TOR_SOCKS_HOST || '127.0.0.1';
  const port = Number(process.env.TOR_SOCKS_PORT || 9050);
  return new Promise<boolean>((resolve) => {
    const socket = net.createConnection({ host, port });
    const finish = (ready: boolean) => {
      socket.destroy();
      resolve(ready);
    };
    socket.setTimeout(1000);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
  });
}

export function registerGatewayRoutes(app: Express) {
  app.get('/health', async (_req, res) => {
    const tor = await torReady();
    res.status(tor ? 200 : 503).json({ status: tor ? 'ok' : 'degraded', service: 'toorock-render-gateway', tor });
  });
  app.all('/gateway/proxy', (req, res) => {
    try {
      const target = parseOnionUrl(req.query.url);
      requestThroughTor(target, req, res);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Invalid target' });
    }
  });
}
