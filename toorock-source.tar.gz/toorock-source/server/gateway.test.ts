import { describe, expect, it } from "vitest";
import { parseGatewayTarget, parseOnionUrl } from "./gateway";

describe("parseOnionUrl", () => {
  const onion = `${"a".repeat(56)}.onion`;

  it("accepts valid v3 onion URLs", () => {
    const target = parseOnionUrl(`https://${onion}/path`);
    expect(target.protocol).toBe("https:");
    expect(target.hostname).toMatch(/\.onion$/);
    expect(target.pathname).toBe("/path");
  });

  it("normalizes an onion hostname without a protocol", () => {
    const target = parseOnionUrl(onion);
    expect(target.protocol).toBe("http:");
  });

  it("rejects clear-web URLs and arbitrary destinations", () => {
    expect(() => parseOnionUrl("https://example.com")).toThrow("valid v3 onion");
    expect(() => parseOnionUrl("http://127.0.0.1")).toThrow("valid v3 onion");
  });

  it("rejects unsupported ports and protocols", () => {
    expect(() => parseOnionUrl(`http://${onion}:8080`)).toThrow("Unsupported target port");
    expect(() => parseOnionUrl(`ftp://${onion}`)).toThrow("Only HTTP and HTTPS");
  });

  it("rejects oversized or malformed input", () => {
    expect(() => parseOnionUrl("x".repeat(2049))).toThrow("Invalid target");
    expect(() => parseOnionUrl("not a url")).toThrow("Invalid target URL");
  });
});

describe("parseGatewayTarget", () => {
  it("allows the restricted DuckDuckGo search host", () => {
    expect(parseGatewayTarget("https://duckduckgo.com/html/?q=tor").hostname).toBe("duckduckgo.com");
  });

  it("rejects arbitrary clear-web hosts", () => {
    expect(() => parseGatewayTarget("https://example.com")).toThrow("Target host is not allowed");
  });
});
